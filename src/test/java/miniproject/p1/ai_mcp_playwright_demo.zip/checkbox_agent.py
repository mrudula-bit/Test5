
from playwright.sync_api import sync_playwright

def run_test():

    with sync_playwright() as p:

        browser = p.chromium.launch(headless=False)

        page = browser.new_page()

        page.goto("file:///PATH_TO/demo_app.html")

        remember = page.locator("#remember")
        subscribe = page.locator("#subscribe")

        print("Initial Remember status:", remember.is_checked())
        print("Initial Subscribe status:", subscribe.is_checked())

        # AI-style logic
        if not remember.is_checked():
            remember.check()
            print("Remember checkbox checked")

        if not subscribe.is_checked():
            subscribe.check()
            print("Subscribe checkbox checked")

        # Validation
        print("Final Remember status:", remember.is_checked())
        print("Final Subscribe status:", subscribe.is_checked())

        page.screenshot(path="result.png")

        print("Screenshot captured: result.png")

        browser.close()

run_test()
