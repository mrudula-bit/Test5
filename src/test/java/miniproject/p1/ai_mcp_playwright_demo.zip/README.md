
# AI Agent Demo Using Playwright + Python + MCP + Claude

## Install

pip install playwright
playwright install

## Run

1. Update PATH_TO in checkbox_agent.py
2. Execute:

python checkbox_agent.py

## What It Does

- Opens demo checkbox application
- Checks checkbox status
- Automatically checks unchecked boxes
- Validates results
- Takes screenshot

## MCP Flow

Claude AI
    ↓
MCP Server
    ↓
Playwright
    ↓
Browser Actions

## Example Claude Prompt

"Open application and check Remember Me checkbox"

